"use client"

import { ColumnDef } from "@tanstack/react-table"
import { Doc } from ".@/convex/_generated/dataModel";
import { useMutation, useQuery } from "convex/react";
import { api } from ".@/convex/_generated/api";




export const columns: ColumnDef<Doc<"assets">>[] = [
  {
    accessorKey: "assetNumber",
    header: (header) => {
      return(
        <span className="font-bold">Asset Tag</span>
      )
    },
    cell: ({row}) => {
      return(
        <span className="font-semibold">{row.original.assetNumber}</span>
      )
    }
  },
  {
    accessorKey: "assetName",
    header: "Name",
    
  },
  {
    accessorKey: "serialNumber",
    header: "Serial Number",
  },
  {
    accessorKey: "assetModel",
    header: "Model",
    cell: ({row}) => {
      const modelResults = useQuery(api.tasks.getModels)
      const manufactureResult = useQuery(api.tasks.getManufactures)
      const model = modelResults?.find(m => m._id === row.original.assetModel)
      const manufacture = manufactureResult?.find(m => m._id === model?.manufacture)
      return`${manufacture?.manufactureName} ${model?.modelName}`
    }
  },
  {
    accessorKey: "storageLocation",
    header: "Storage Location",
    cell: ({row}) => {
      const locationResult = useQuery(api.tasks.getLocations)
      const location = locationResult?.find(m => m._id === row.original.storageLocation)
      return location?.locationName
    }
  },
  {
    accessorKey: "_creationTime",
    header: "Created At",
    cell: ({row}) => {
      return new Date(row.original._creationTime).toLocaleDateString("en-AU")
    }
  }
]
