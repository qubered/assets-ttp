"use client"

import { useQuery } from "convex/react"
import { api } from "../../../../convex/_generated/api"
import { DataTable } from "@/components/data-table"
import { columns } from "./columns"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function AssetsPage() {
  const assetsResult = useQuery(api.tasks.getAssets) ?? []

  return (
    <div className="container mx-auto py-10">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Assets</h1>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          New Asset
        </Button>
      </div>
      <div className="mt-4">
        <DataTable columns={columns} data={assetsResult} />
      </div>
    </div>
  )
}